# Keskustelufoorumi

Tietokantojen perusteet -kurssin harjoitustyönä tehty keskutelufoorumi.

